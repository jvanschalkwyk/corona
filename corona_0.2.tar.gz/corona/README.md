# corona
Supporting code for the book "I Nanny Rona", a coronavirus autobiography!
